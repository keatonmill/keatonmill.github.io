# Monte Carlo for MPTC revisions
# Keaton Miller, September 2019
# revised for RR2 September 2022
println("Start montecarlo_driver.jl")

path_to_mc = "MC.jl"

include(path_to_mc)
using Random
using LinearAlgebra
using Distributions
using DataFrames
using Plots
using Printf


println("Making graphs for a single simulation output")
Random.seed!(12359)

mkt_draws = randn(50) * 0.1
base = MC.Market(4, 2, 2, 2)
(df, true_data) = MC.DoSimulationRun(base; number = 50, preset_draws = mkt_draws, returndataframe=true)

inputs = range(0.0, 1.0, length=50)
onefirm = df[(df.firm .== 1) .& (df.product .== 1), :]
y = hcat(onefirm[:,:char1], onefirm[:,:char2], onefirm[:,:price])
pl = plot(inputs, y, label=["Char. 1" "Char. 2" "Price"], 
          xlabel="Period 1 subsidy",
          ylabel="Action",
          title="(a) Equilibrium strategy for firm 1, product 1",
          seriestype=:scatter, dpi=600, legend=:right)
display(pl)
savefig(pl, "figures for draft/mc-sample-policy-function.png")

inputs = range(1.0, 0.0, length=50)
onefirm = true_data[(true_data.firm .== 1) .& (true_data.product .== 1), :]
y = hcat((onefirm[:,:sim_char1] .- onefirm[:,:char1]), 
          (onefirm[:,:sim_char2] .- onefirm[:,:char2]))
pl = plot(inputs, y, seriestype=:scatter, dpi=600, legend=:topright,
          label=["Char. 1" "Char. 2"],
          xlabel="Period 2 subsidy",
          ylabel="Approximate char. - true char.",
          title="(b) Policy function approximation error")
display(pl)
savefig(pl, "figures for draft/mc-sample-char-approximation.png")


inputs = range(1.0, 0.0, length=50)
onefirm = true_data[(true_data.firm .== 1) .& (true_data.product .== 1), :]
y = hcat(onefirm[:,:price], onefirm[:, :sim_price_fit], onefirm[:,:sim_price])
ydiff = hcat(y[:,2] .- y[:,1], y[:,3] .- y[:,1])
pl = plot(inputs, ydiff, label=["Policy approx." "Augmented approx."],
          ylabel="Approximate price minus true price",
          xlabel = "Period 2 subsidy",
          title= "(c) Approximation errors for prices",
          seriestype=:scatter,dpi=600, legend=:top)
display(pl)
savefig(pl, "figures for draft/mc-sample-price-approximation.png")


inputs = range(1.0, 0.0, length=50)
onefirm = true_data[(true_data.firm .== 1) .& (true_data.product .== 1), :]
y = hcat(onefirm[:,:cs], onefirm[:, :sim_cs_fit], onefirm[:, :sim_cs])
ydiff = hcat((y[:,2] .- y[:,1]) ./ y[:,1] * 100, (y[:,3] .- y[:,1]) ./ y[:,1] * 100)
pl = plot(inputs, ydiff, label=["Policy approx." "Augmented approx."], 
          xlabel="Period 2 subsidy",
          ylabel="Error as a percentage of true welfare",
          title="(d) Approximation errors for welfare",
          seriestype=:scatter, dpi=600, legend=:right)
display(pl)
savefig(pl, "figures for draft/mc-sample-consumer-welfare.png")
println("Done making graphs.")


println("Making table of multiple simulation runs")
mkt_draw_seed = 524862
base_draw_seed = 83187

# what runs are we doing?
list_firms = [1,2,4]
list_prods = [1,2,4]
list_mkts = [50, 100, 200]

run_output = Array{Tuple{Float64,Float64,Float64,Float64}}(undef, length(list_firms), length(list_prods), length(list_mkts))

# generate consistent market-level draws
mkt_draws = Array{Array{Float64,1},1}(undef, length(list_mkts))
for m in 1:length(list_mkts)
  Random.seed!(mkt_draw_seed)
  mkt_draws[m] = randn(list_mkts[m]) * 0.1
end


for f in 1:length(list_firms)
  for p in 1:length(list_prods)
    # generate one base market to use for this set of sims
    Random.seed!(base_draw_seed)
    base = MC.Market(list_firms[f],list_prods[p],list_prods[p],list_prods[p])
    for m in 1:length(list_mkts)
      println("NEW RUN: $(list_firms[f]) firms, $(list_prods[p]) product complexity, $(list_mkts[m]) markets.")
      # generate market
      run_output[f, p, m] = MC.DoSimulationRun(base; number = list_mkts[m], preset_draws = mkt_draws[m])
      println("DONE WITH RUN $(list_firms[f]), $(list_prods[p]), $(list_mkts[m]) \n\n")
    end
  end
end

function nf(num)
  if num > 1000
    return @sprintf "%.0f" num
  end
  if num > 100
    return @sprintf "%.1f" num
  end
  if num > 10
    return @sprintf "%.2f" num
  end
  if num > 1
    return @sprintf "%.3f" num
  end
  return @sprintf "%.4f" num
end

# make a nice table for the error in characteristics
println("Characteristics table")
for f in 1:length(list_firms)
  for p in 1:length(list_prods)
    print("$(list_firms[f])\t& $(list_prods[p])\t& $(list_prods[p])\t")
    for m in 1:length(list_mkts)
      th = run_output[f, p, m]
      print("& $(nf(th[1]))\t& $(nf(th[2]))\t")
    end
    println("\\\\")
  end
  println("\\hline")
end
println("\n\n")
# make a nice table for consumer surplus
println("Consumer Surplus table")
for f in 1:length(list_firms)
  for p in 1:length(list_prods)
    print("$(list_firms[f])\t& $(list_prods[p])\t& $(list_prods[p])\t")
    for m in 1:length(list_mkts)
      th = run_output[f, p, m]
      print("& $(nf(th[3]))\t& $(nf(th[4]))\t")
    end
    println("\\\\")
  end
  println("\\hline")
end

println("Done making tables")

println("Done with montecarlo_driver.jl")
