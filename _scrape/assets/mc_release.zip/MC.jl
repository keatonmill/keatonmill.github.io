module MC


using ForwardDiff
using LinearAlgebra
using NLopt
using NLsolve
using Random
using Plots
using DataFrames
using Distributions
using FixedEffectModels
using CategoricalArrays

include("Util.jl")

# type for market parameters
mutable struct Market
  id::Int64
  nFirms::Int64
  nChars::Int64
  nProds::Int64
  nTypes::Int64
  subsidy::Float64
  market_cost_shock::Float64
  alpha::Array{Float64,1}
  beta::Array{Array{Float64,1},1}
  shocks::Array{Float64,1}
  char_costs::Array{Float64,1}
  Market(i, f, c, p, t, su, mcs, al, be, sh, cc) = new(i, f, c, p, t, su, mcs, al, be, sh, cc)
end

# this function randomly generates the market preferences and shock parameters for a basic market
function Market(nFirms::Int64, nChars::Int64, nProds::Int64, nTypes::Int64)
  id = 0
  subsidy = 0.0
  market_cost_shock = 0.0
  alpha = ones(nTypes) .* -2.5
  beta = Array{Float64,1}[]
  for t in 1:nTypes
    this_beta = zeros(nChars)
    for d in 1:nChars
      if d == t
        this_beta[d] = randn()* 0.1 + 2.5
      else
        this_beta[d] = randn() * 0.01 + 0.1
      end
    end
    push!(beta, this_beta)
  end

  # have to transform the firm shocks into product shocks
  firm_shocks = randn(nFirms) * .01 .- 0.5
  shocks = repeat(firm_shocks, nProds)

  char_costs = randn(nChars) * .01 .+ 0.1

  # now we have everything
  return Market(id, nFirms, nChars, nProds, nTypes, subsidy, market_cost_shock, alpha, beta, shocks, char_costs)
end


# type to make things efficient when we're solving equilibria
mutable struct ScratchPad
  scr_cost_work::Array{Float64,2}
  scr_share_sumchar::Array{Float64,1}
  scr_share_exb::Array{Float64,1}
  scr_prof_share::Array{Float64,1}
  scr_prof_cost::Array{Float64,1}
  ScratchPad(cw, ss, se, ps, pc) = new(cw, ss, se, ps, pc)
end

function ScratchPad(m::Market)
  # allocate memory
  cw = zeros(m.nFirms * m.nProds, m.nChars)
  ss = zeros(m.nFirms * m.nProds)
  se = similar(ss)
  ps = similar(ss)
  pc = similar(ss)
  return ScratchPad(cw, ss, se, ps, pc)
end


function Costs!(pre, chars, m::Market, s::ScratchPad)
  s.scr_cost_work .= chars .* chars .* m.char_costs'
  sum!(pre,  s.scr_cost_work)
  pre .= exp.(0.2 .+ pre .+ m.shocks .+ m.market_cost_shock)
end

function Costs(chars, m::Market)
  return exp.(0.2 .+ (chars .* chars) * m.char_costs .+ m.shocks .+ m.market_cost_shock)
end

# calculates product-by-product shares
function Shares(prices, chars, m::Market)
  share = zeros(length(prices))
  for t in 1:m.nTypes
    #e_xb = exp.(m.beta[t] .* Util.rowsum(chars) .+ m.alpha[t] .* prices .* prices)
    e_xb = exp.(chars * m.beta[t] .+ m.alpha[t] .* prices .* prices)
    share += e_xb ./ (1 + sum(e_xb)) ./ m.nTypes
  end
  #e_xb = exp.(Util.rowsum(chars) .+ m.alpha .* prices .* prices)
  #share = e_xb ./ (1 + sum(e_xb))
  return share
end

# now do it with scratch memory
function Shares!(pre, prices, chars, m::Market, s::ScratchPad)
  # set our preallocated memory to zero and then we'll accumulate shares
  pre .= 0.0
  for t in 1:m.nTypes
    #s.scr_share_sumchar .= chars * m.beta[t] # the below line is faster, even though it's effectively doing the same thing!
    LinearAlgebra.mul!(s.scr_share_sumchar, chars, m.beta[t])
    s.scr_share_exb .= exp.(s.scr_share_sumchar .+ m.alpha[t] .* prices .* prices)
    pre .+= s.scr_share_exb ./ (sum(s.scr_share_exb) + 1) ./ m.nTypes
  end
end

function ConsumerSurplus(prices, chars, m::Market)
  cs = 0.0
  for t in 1:m.nTypes
    e_xb = exp.(chars * m.beta[t] + m.alpha[t] .* prices .* prices)
    cs += abs(1.0/m.alpha[t]) * log(1.0 + sum(e_xb)) / m.nTypes
  end
  return cs
end

function Profits(prices, chars,  m::Market)
  product_profits = (prices .- Costs(chars, m) .+ m.subsidy) .* Shares(prices, chars, m)
  re = reshape(product_profits, m.nFirms, m.nProds)
  return Util.rowsum(re)
end

function PreProfits!(pre, prices, chars, m::Market, s::ScratchPad)
  Shares!(s.scr_prof_share, prices, chars, m, s)
  Costs!(s.scr_prof_cost, chars, m, s)

  # product-level profits, reuse the share memory
  s.scr_prof_share .= (prices .- s.scr_prof_cost .+ m.subsidy) .* s.scr_prof_share

  #sum!(pre, reshape(s.scr_prof_share, m.nFirms, m.nProds)) # this allocates memory

  # set our preallocated memory to zero and then we'll accumulate profits
  pre .= 0.0
  for f in 1:m.nFirms
    for j in 1:m.nProds
      pre[f] += s.scr_prof_share[m.nFirms * (j-1) + f]
    end
  end
end

function SplitStack(in, F::Int64, C::Int64)
  prices = in[1:F]
  chars = reshape(in[F+1:end], (F,C))
  return (prices, chars)
end

function SplitStack(in, m::Market)
  return SplitStack(in, m.nFirms * m.nProds, m.nChars)
end

function ProfitStack(in, m::Market)
  # need to turn the stacked parameters into two matrices
  (prices, chars) = SplitStack(in, m)
  return Profits(prices, chars, m)
end

function SortProducts(in, m::Market)
  # get prices and characteristics
  (prices, chars) = SplitStack(in, m)

  # allocate space for the new prices and chars, just to be safe
  new_prices = similar(prices)
  new_chars = similar(chars)

  # loop through each firm and sort individually
  for f in 1:m.nFirms
    thisfirm_products = [(p-1)*m.nFirms + f for p in 1:m.nProds]
    thisfirm_prices = prices[thisfirm_products]
    thisfirm_chars = chars[thisfirm_products, :]
    thisfirm_order = sortperm(thisfirm_chars[:,1], rev=true)

    # now we can stick stuff into our new vector in the right way
    new_prices[thisfirm_products] = thisfirm_prices[thisfirm_order]
    new_chars[thisfirm_products,:] = thisfirm_chars[thisfirm_order,:]
  end
  out = vcat(new_prices, reshape(new_chars, (m.nFirms * m.nChars * m.nProds, 1)))

  return out
end


function GraphSingleFirmProfits(totest, which, m::Market, ttl="GraphSingleFirmProfits", left = -2.0, right = 4.0, len = 500)
  println("Graphing profits for firm $which as a function of all components of @ $totest")
  lab = []
  for j in 1:m.nProds
    for f in 1:m.nFirms
      push!(lab, "Firm $f Product $j Price")
    end
  end
  for k in 1:m.nChars
    for j in 1:m.nProds
      for f in 1:m.nFirms
        push!(lab, "Firm $f Product $j Char $k")
      end
    end
  end
  f(y) = ProfitStack(y, m)[which]
  for i in 1:length(totest)
    println(i)
    in = range(left, right, length=len)
    output = zeros(length(in))
    for j in 1:length(in)
      tmp = deepcopy(totest)
      tmp[i] = in[j]
      output[j] = f(tmp)
    end
    p = plot(in, output)
    vline!(p, [totest[i]])
    xlabel!(p, lab[i])
    ylabel!(p, "Profit for $which")
    title!(p, ttl)
    display(p)
  end
end

function GraphAllFirmProfits(totest, m::Market, ttl="GraphAllFirmProfits", left = -2.0, right = 4.0, len = 500)
  println("Graphing profits for all firms as a function of their choice variables @ $totest")
  # loop over the firms
  inputs = range(left, right, length=len)
  for j in 1:m.nFirms
    println("\tfirm $j")

    f(y) = ProfitStack(y, m)[j]

    output_price = zeros(length(inputs), m.nProds)
    output_char = zeros(length(inputs), m.nProds, m.nChars) # need an output char for each of these

    # get the price output
    for p in 1:m.nProds
    tmp_price = deepcopy(totest)
      for k in 1:length(inputs)
        tmp_price[m.nFirms * (p-1) + j] = inputs[k]
        output_price[k, p] = f(tmp_price)
      end
    end

    # now loop through the chars and get all of their output
    #=
    for 4 firms, 2 products, 2 product characteristics...
    firm	product	char
    j	p	d	OUT
    1	1	1	9
    1	1	2	17
    1	2	1	13
    2	1	1	10
    =#
    for p in 1:m.nProds
      for d in 1:m.nChars
        tmp_char = deepcopy(totest)
        for k in 1:length(inputs)
          tmp_char[m.nFirms*m.nProds + (p-1) * m.nFirms + (d-1) * m.nFirms * m.nProds + j] = inputs[k]
          output_char[k, p, d] = f(tmp_char)
        end
      end
    end
    for p in 1:m.nProds
      pl = plot(inputs, output_price[:,p])
      level = totest[(p-1)*m.nFirms + j]
      vline!(pl, [level])
      xlabel!(pl, "Firm $j Product $p Price, $level")
      ylabel!(pl, "Profit for $j")
      title!(pl, ttl)
      display(pl)
    end

    # output graphs for product characteristics
    for p in 1:m.nProds
      for d in 1:m.nChars
        pl = plot(inputs, output_char[:,p,d])
        level = totest[m.nFirms*m.nProds + (p-1) * m.nFirms + (d-1) * m.nFirms * m.nProds + j]
        vline!(pl, [level])
        xlabel!(pl, "Firm $j Product $p Char $d, $level")
        ylabel!(pl, "Profit for $j")
        title!(pl, ttl)
        display(pl)
      end
    end
  end
end

function BestResponse(in, which, m::Market, s::ScratchPad)
  # set up the profit function for this particular firm
  # want to preallocate the memory which we'll be playing with
  (action_price, action_char) = SplitStack(in, m)

  # preallocate the profit vector
  pre_profit = zeros(m.nFirms,1)

  function Prof(x, which, action_price, action_char, pre_profit, m::Market, s::ScratchPad)
    # the first Xs are the prices
    for p in 1:m.nProds
      action_price[(p-1)*m.nFirms + which] = x[p]
    end
    # then the characteristics
    for p in 1:m.nProds
      for d in 1:m.nChars
        action_char[(p-1)*m.nFirms + which, d] = x[m.nProds + (d-1)*m.nProds + p]
      end
    end
    PreProfits!(pre_profit,action_price, action_char, m,s)
    #println("tried $x, got $(pre_profit[which])")
    return pre_profit[which]
  end

  # now set up what we need for NLopt, which is nuts because we have all of this pre-allocated stuff
  F(x, grad) = Prof(x, which, action_price, action_char, pre_profit, m, s)

  # need to get the action vector for the firm -- add one to m.nChars to represent the price
  start_x = zeros(m.nProds * (m.nChars + 1))
  for p in 1:m.nProds
    start_x[p] = in[(p-1)*m.nFirms + which]
  end
  # now the characteristics
  for p in 1:m.nProds
    for d in 1:m.nChars
      start_x[m.nProds + (d-1)*m.nProds + p] = in[m.nFirms*m.nProds + (p-1)*m.nFirms + (d-1) * m.nFirms * m.nProds + which]
    end
  end

  test = F(start_x, [])

  opt = Opt(:LN_SBPLX, length(start_x))
  max_objective!(opt, F)
  initial_step!(opt, 1e-5)
  opt.maxeval = 5000
  (maxf, maxx, ret) = optimize(opt, start_x)
  #println("got $maxf at $maxx (returned $ret)")

  return maxx
end

function BestResponseStep(in, m::Market, s::ScratchPad)
  out = deepcopy(in)
  for f in 1:m.nFirms
    tmp = BestResponse(in, f, m,s)
    # put the prices back in
    for p in 1:m.nProds
      out[(p-1)*m.nFirms + f] = tmp[p]
    end
    # now all of the product characteristics
    for p in 1:m.nProds
      for d in 1:m.nChars
        out[m.nFirms*m.nProds + (p-1)*m.nFirms + (d-1) * m.nFirms * m.nProds + f] = tmp[m.nProds + (d-1)*m.nProds + p]
      end
    end
  end
  return out
end

function SolveBestResponse(start, m::Market, s::ScratchPad)
  #println("Solving with BestResponse at $start")
  last = deepcopy(start)
  cur = deepcopy(last)
  dist = Inf
  last_dist = dist
  i = 0
  ratio = 0.5
  while i < 500
    i += 1
    last .= cur
    last_dist = dist
    cur = BestResponseStep(last, m, s)
    dist = sqrt(sum((cur .- last).^2))
    # but only move halfway
    cur .= (1.0-ratio) .* cur .+ ratio .* last
    #println("\ti=$i, dist=$dist")# cur=$cur, last=$last")
    if dist < 1e-7
      break
    end
    if dist > last_dist
      ratio = ratio * .9
      #println("\tBacked up. ratio is now $ratio.")
    end
  end

  #println("\tFinished in $i with $dist and $ratio. Output is $cur")
  return SortProducts(cur, m)
end

function ForwardFOC(in, m::Market)
  f(x) = ProfitStack(x, m)
  foc = ForwardDiff.jacobian(f, in)::Array{Float64,2}
  return foc
end


function ProfitFOC(in, m::Market)
  full_foc = ForwardFOC(in, m)
  out = zeros(length(in))
  # all of the FOCs come from diagonals! so we can just loop through and grab them
  for i in 1:length(in)
    out[i] = full_foc[mod(i-1,m.nFirms)+1,i]
  end
  return out
end


function FOCWrapper(in, m::Market)
  out = ProfitFOC(in, m)
  return sqrt(sum(out .* out))
end

function SolveWrapper!(out, in, m::Market)
  out .= ProfitFOC(in, m)
end

function GraphFOC(totest, m::Market, ttl="notitle", left = -2.0, right = 4.0, len = 500)
  println("Graphing FOC @ $totest")
  lab = []
  for j in 1:m.nProds
    for f in 1:m.nFirms
      push!(lab, "Firm $f Product $j Price")
    end
  end
  for k in 1:m.nChars
    for j in 1:m.nProds
      for f in 1:m.nFirms
        push!(lab, "Firm $f Product $j Char $k")
      end
    end
  end
  f(y) = FOCWrapper(y, m)
  for i in 1:length(totest)
    println(i)
    in = range(left, right, length=len)
    output = zeros(length(in))
    for j in 1:length(in)
      tmp = deepcopy(totest)
      tmp[i] = in[j]
      output[j] = f(tmp)
    end
    p = plot(in, output)
    vline!(p, [totest[i]])
    xlabel!(p, lab[i])
    ylabel!(p, "FOC Obj")
    title!(p, ttl)
    display(p)
  end
end

function SolveMarketAndExportData(m::Market)
  # make the scratchpad
  s = ScratchPad(m)

  # set up a starting point for the solver
  startchars = zeros(m.nFirms * m.nProds, m.nChars)

  # set a product characteristic to one for each product
  for i in 1:m.nProds
    startchars[((i-1) * m.nFirms + 1):i*m.nFirms, mod(i, m.nChars)+1] .= 1.0
  end

  costs = MC.Costs(startchars, m)
  startprices = costs .* 1.01
  start = vcat(startprices, reshape(startchars, (m.nFirms * m.nChars * m.nProds, 1)))

  # solve the market!
  solution = MC.SolveBestResponse(start, m, s)

  # now we need the columns for the DataFrame
  nObs = m.nFirms * m.nProds

  # transform the output into prices and chars
  (prices, chars) = SplitStack(solution, m)

  # get the shares
  shares = Shares(prices, chars, m)

  # and the true costs
  costs = Costs(chars, m)

  # and the consumer surplus, which is a constant
  cs = ConsumerSurplus(prices, chars, m)

  # need the firm and product ids
  firm_id = zeros(Int64, nObs)
  product_id = zeros(Int64, nObs)
  for p in 1:m.nProds
    for f in 1:m.nFirms
      firm_id[(p-1) * m.nFirms + f] = f
      product_id[(p-1) * m.nFirms + f] = p
    end
  end

  # now everything should just work!
  df = DataFrame()

  df.mkt = repeat([m.id], nObs)
  df.firm = firm_id
  df.product = product_id
  df.subsidy = repeat([m.subsidy], nObs)
  df.share = shares
  df.price = prices
  df.cs = repeat([cs], nObs)

  # getting the variable number of product characteristics in there is annoying
  # use the Symbol() function to transform a string into a symbol which can be used to add the column
  for i in 1:m.nChars
    df[!, Symbol("char$i")] = chars[:,i]
  end

  # add the market specific cost shock
  df.mkt_shock = repeat([m.market_cost_shock], nObs)

  # and the firm cost shocks
  df.firm_shock = m.shocks

  for i in 1:m.nChars
    df[!, Symbol("charcost$i")] = repeat([m.char_costs[i]], nObs)
  end

  df.cost = costs

  return df

end

function GetMarketData(ms::Vector{Market})
  dfs = Array{DataFrame}(undef,length(ms))
  #Threads.@threads for i in 1:length(ms)
  ansi_moveup="\e[1A"
  ansi_clearline="\e[2K"
  ansi_movecol1 ="\e[1G"
  println("\t\tGetMarketData: Start")
  for i in 1:length(ms)
    #if mod(i, 10) == 0; println("\t\tgmd on mkt $i of $(length(ms))"); end
    print(ansi_moveup * ansi_clearline * ansi_movecol1)
    println("GetMarketData: Market $i/$(length(ms))")
    dfs[i] = SolveMarketAndExportData(ms[i])
  end

  out = deepcopy(dfs[1])
  if length(dfs) > 1
    for i in 2:length(dfs)
      append!(out, dfs[i])
    end
  end
  return out
end

function OneMarketManySubsidies(m::Market, number = 50, low = 0.0, high = 1.0)
  subsidies = range(low, high, length=number)
  ms = Market[]
  for i in 1:number
    tmp = deepcopy(m)
    tmp.subsidy = subsidies[i]
    push!(ms, tmp)
  end
  return ms
end

function BaseMarketToManyMarkets(m::Market, number = 50, low = 0.0, high = 1.0, preset_draws = [])
  subsidies = range(low, high, length = number)
  ms = Market[]
  for i in 1:number
    tmp = deepcopy(m)
    tmp.subsidy = subsidies[i]
    tmp.id = i
    if preset_draws == []
      tmp.market_cost_shock = randn()*0.1
    else
      tmp.market_cost_shock = preset_draws[i]
    end
    push!(ms, tmp)
  end
  return ms
end


function BestResponsePriceOnly(in_price, in_char, which, m::Market, s::ScratchPad)
  # set up the profit function for this particular firm using only prices
  action_price = deepcopy(in_price)

  # preallocate the profit vector
  pre_profit = zeros(m.nFirms,1)

  function Prof(x, which, action_price, in_char, pre_profit, m::Market, s::ScratchPad)
    # we're only updating the prices on this one
    for p in 1:m.nProds
      action_price[(p-1)*m.nFirms + which] = x[p]
    end
    PreProfits!(pre_profit,action_price, in_char, m,s)
    #println("tried $x, got $(pre_profit[which])")
    return pre_profit[which]
  end

  # now set up what we need for NLopt, which is nuts because we have all of this pre-allocated stuff
  F(x, grad) = Prof(x, which, action_price, in_char, pre_profit, m, s)

  # need to get the action vector for the firm -- which in this case is only prices
  start_x = zeros(m.nProds)
  for p in 1:m.nProds
    start_x[p] = in_price[(p-1)*m.nFirms + which]
  end

  # we hit this once to precompile and also to kick out any errors, because if
  # NLopt hits an error it just stops and doesn't throw it up through the rest
  # of the callstack.
  test = F(start_x, [])

  opt = Opt(:LN_SBPLX, length(start_x))
  max_objective!(opt, F)
  initial_step!(opt, 1e-5)
  opt.maxeval = 5000
  (maxf, maxx, ret) = optimize(opt, start_x)
  #println("got $maxf at $maxx (returned $ret)")

  return maxx
end

function BestResponseStepPriceOnly(in_price, in_char, m::Market, s::ScratchPad)
  out_price = deepcopy(in_price)
  for f in 1:m.nFirms
    tmp = BestResponsePriceOnly(in_price, in_char, f, m,s)
    # put the prices back in
    for p in 1:m.nProds
      out_price[(p-1)*m.nFirms + f] = tmp[p]
    end
  end
  return out_price
end

function SolveBestResponsePriceOnly(in_price, in_char, m::Market, s::ScratchPad)
  #println("Solving with BestResponsePriceOnly at $in_price with $in_char")
  last = deepcopy(in_price)
  cur = deepcopy(last)
  dist = Inf
  last_dist = dist
  i = 0
  ratio = 0.5
  while i < 500
    i += 1
    last .= cur
    last_dist = dist
    cur = BestResponseStepPriceOnly(last, in_char, m, s)
    dist = sqrt(sum((cur .- last).^2))
    # but only move halfway
    cur .= (1.0-ratio) .* cur .+ ratio .* last
    #println("\ti=$i, dist=$dist")# cur=$cur, last=$last")
    if dist < 1e-7
      break
    end
    if dist > last_dist
      ratio = ratio * .9
      #println("\tBacked up. ratio is now $ratio.")
    end
  end

  #println("\tFinished in $i with $dist and $ratio. Output is $cur")
  return cur
end

function ReverseSubsidies(oldmarkets)
  newmarkets = deepcopy(oldmarkets)
  for i in 1:length(oldmarkets)
    newmarkets[i].subsidy = oldmarkets[length(oldmarkets)-i+1].subsidy
  end
  return newmarkets
end

function DoSimulationRun(m::Market; number = 50, low = 0.0, high = 1.0, preset_draws = [], returndataframe = false)
  # fill out all of the markets
  mkts = BaseMarketToManyMarkets(m, number, low, high, preset_draws)

  # get a scratchpad based on our base market
  s = ScratchPad(m)

  # solve the markets in "period 1"
  println("\tSolving markets in period 1...")
  df = GetMarketData(mkts)

  # add firm fixed effects
  df.firmcat = categorical(df.firm)

  # do regressions to get the coefficients we need
  coeff = zeros(m.nProds, m.nChars)

  # RR2: also need price coefficients
  coeff_price = zeros(m.nProds)

  for p in 1:m.nProds
    for d in 1:m.nChars
      # generate the dataset
      tmp_df = df[df.product .== p, [Symbol("char$d"), :subsidy, :firmcat]]
      # rename the column
      rename!(tmp_df, Symbol("char$d") => :char)
      # do the regression
      out = reg(tmp_df, @formula(char ~ subsidy + fe(firmcat)), Vcov.robust())
      coeff[p, d] = coef(out)[1]
      # do the price regression
      tmp_df_price = df[df.product .== p, [:price, :subsidy, :firmcat]]
      out_price = reg(tmp_df_price, @formula(price ~ subsidy + fe(firmcat)), Vcov.robust())
      coeff_price[p] = coef(out_price)[1]
    end
  end

  # to get the characteristics out, we have to create a bunch of symbols
  char_symbols = Array{Symbol,1}()
  sim_char_symbols = Array{Symbol,1}()
  for d in 1:m.nChars
    push!(char_symbols, Symbol("char$d"))
    push!(sim_char_symbols, Symbol("sim_char$d"))
  end

  # get the true period 2 data
  println("\tSolving markets in period 2...")
  newmarkets = ReverseSubsidies(mkts)
  true_data = MC.GetMarketData(newmarkets)
  true_prices = convert(Array, true_data[:, :price])
  true_cs = convert(Array, true_data[:, :cs])
  true_chars = Matrix(true_data[:, char_symbols])

  sim_prices = similar(true_prices)
  sim_prices_fit = similar(true_prices)
  sim_chars = similar(true_chars)
  sim_cs = similar(true_cs)
  sim_cs_fit = similar(true_cs)

  # loop through markets, update product characteristics, solve for new prices
  println("\tSimulating markets in period 2")
  ansi_moveup="\e[1A"
  ansi_clearline="\e[2K"
  ansi_movecol1 ="\e[1G"
  println("\t\tStart.")
  for mi in 1:number
    #if mod(mi, 10) == 0; println("\t\tnow on market $mi"); end
    print(ansi_moveup * ansi_clearline * ansi_movecol1)
    println("\t\tMarket $mi/$number")

    # get product characteristics out, using the symbol array we made earlier
    mkt_data = df[df.mkt .== mi, :]
    mkt_prices = convert(Array,mkt_data[:, :price])
    mkt_char = Matrix(mkt_data[:, char_symbols])
    mkt_prices_fit = deepcopy(mkt_prices)

    # update product characteristics and simulated prices
    # new_characteristic = (new_subsidy - old_subsidy) * coeff_on_subsidy + old_characteristic
    # new_price = (new_subsidy - old_subsidy) * coeff_on_price + old_price
    for f in 1:m.nFirms
      for p in 1:m.nProds
        for d in 1:m.nChars
          mkt_char[(p-1)*m.nFirms + f, d] += (newmarkets[mi].subsidy - mkts[mi].subsidy) * coeff[p,d]
        end
        mkt_prices_fit[(p-1)*m.nFirms + f] += (newmarkets[mi].subsidy - mkts[mi].subsidy) * coeff_price[p]
      end
    end

    # solve for new prices given updated characteristics
    # note that this uses the true costs, which is fine because the estimator gets it exactly right anyway
    new_prices = SolveBestResponsePriceOnly(mkt_prices, mkt_char, newmarkets[mi], s)

    # now we have the data we need, stick it in an array
    sim_prices[((mi-1) * m.nFirms * m.nProds + 1):mi*m.nFirms*m.nProds] = new_prices
    sim_chars[((mi-1) * m.nFirms * m.nProds + 1):mi*m.nFirms*m.nProds, :] = mkt_char
    sim_prices_fit[((mi-1) * m.nFirms * m.nProds + 1):mi*m.nFirms*m.nProds] = mkt_prices_fit

    # get the consumer surplus, both with solved prices and fitted prices
    sim_cs[((mi-1) * m.nFirms * m.nProds + 1):mi*m.nFirms*m.nProds] .= ConsumerSurplus(new_prices, mkt_char, newmarkets[mi])
    sim_cs_fit[((mi-1) * m.nFirms * m.nProds + 1):mi*m.nFirms*m.nProds] .= ConsumerSurplus(mkt_prices_fit, mkt_char, newmarkets[mi])
  end # end of loop through markets

  # fill in the dataset
  true_data.sim_price = sim_prices
  true_data.sim_price_fit = sim_prices_fit
  for d in 1:m.nChars
    true_data[!, Symbol("sim_char$d")] = sim_chars[:,d]
  end
  true_data.sim_cs = sim_cs
  true_data.sim_cs_fit = sim_cs_fit

  # now we need to get the distance metrics
  err_delta_fit = 0.0
  err_delta = 0.0
  err_cs_fit = 0.0
  err_cs = 0.0
  
  for mi in 1:number
    # get the market-level data out
    true_action = true_data[(true_data.mkt .== mi), vcat(:price, char_symbols)]
    true_action = Matrix(true_action)
    
    sim_action = true_data[(true_data.mkt .== mi), vcat(:sim_price, sim_char_symbols)]
    sim_action = Matrix(sim_action)

    sim_action_fit = true_data[(true_data.mkt .== mi), vcat(:sim_price_fit, sim_char_symbols)]
    sim_action_fit = Matrix(sim_action_fit)

    true_cs = (true_data[(true_data.mkt .== mi), :cs])[1]
    sim_cs = (true_data[(true_data.mkt .== mi), :sim_cs])[1]
    sim_cs_fit = (true_data[(true_data.mkt .== mi), :sim_cs_fit])[1]

    # calculate the distance
    #                   D(δexact, δapprox)                    /     ||δExact||
    metric_action = sqrt(sum((true_action .- sim_action).^2)) / sqrt(sum(true_action.^2))
    metric_action_fit = sqrt(sum((true_action .- sim_action_fit).^2)) / sqrt(sum(true_action.^2))
    metric_cs = abs(log(true_cs) - log(sim_cs))
    metric_cs_fit = abs(log(true_cs) - log(sim_cs_fit))

    # add it to the current error
    err_delta_fit += metric_action_fit / number
    err_delta += metric_action / number
    err_cs_fit += metric_cs_fit / number
    err_cs += metric_cs / number
    
  end

  if returndataframe == true
    return (df, true_data)
  end

  return (err_delta_fit, err_delta, err_cs_fit, err_cs)
end # DoSimulationRun

end # module MC
