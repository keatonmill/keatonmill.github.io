# utility functions useful for us

module Util

using Dates
  # function panelsetup mirrors the stata mata function
  # no error checking or bounds checking, so be careful!
  # this isn't very fast and allocates a ton of memory. thankfully, it doesn't have to be fast right now
  function panelsetup(mat::AbstractArray, idcol::Integer)
    n = size(mat, 1) # how many rows are in our matrix?

    # one bound that we do need to check is if the matrix has only one row
    # if so, we need to just return a single thing
    if n == 1
      return [1 1]
    end

    curid = mat[1,idcol]
    np = 0
    # find the first time an id is different
    ep = 0
    foundone = 0
    for i in 2:n
      if mat[i,idcol] != curid
        curid = mat[i, idcol]
        ep = i
        foundone = 1
        break
      end
    end

    # if we never found one, the whole matrix is one panel
    if foundone == 0
      return [1 n]
    end

    # now ep contains the id of the second panel
    inf = [1 ep-1]

    # now we can find more panels!
    for i in ep:n
      if mat[i,idcol] != curid
        curid = mat[i, idcol]
        inf = vcat(inf, [ep i-1])
        ep = i
      end
    end

    # need to stick the last panel on there
    inf = vcat(inf, [ep n])

    return inf
  end

  function panelsubmatrix(mat, i::Integer, info::AbstractArray)
    return deepcopy(mat[info[i,1]:info[i,2],:])
  end

  function rowsum(mat)
    return sum(mat, dims=2)
  end

  function colsum(mat)
    return sum(mat, dims=1)
  end

  function datestring()
    return Dates.format(now(), "yyyy-mm-dd--HH-MM-SS")
  end

end
