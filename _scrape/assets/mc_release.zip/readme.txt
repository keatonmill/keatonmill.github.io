README for Monte Carlo code for 
	The Optimal Geographic Distribution of 
	Managed Competition Subsidies
	Appendix D
	
Release 2022/09/21 (commit 77a089)

by Keaton Miller
	keaton.miller@gmail.com
	https://keatonmiller.org
	
This code is released under the Creative Commons Attribution (CC BY) license. If you wish to use the code for purposes or in ways not covered by the CC BY license, please contact me.

This release contains the Julia code that generates the Monte Carlo results of Appendix D. The code is contained in three files. "MC.jl" defines a Julia module with types and functions that solve equilibria in the simplified model of Appendix D and run simulated approximate counterfactuals. "Util.jl" defines a Julia module with a few utility functions. "montecarlo_driver.jl" is a Julia program which, when executed, creates the graphs and tables seen in the paper.

The "hard problem" of this code is solving equilibria efficiently -- i.e. with a minimal number of potential equilibrium outcomes tested and with a minimal amount of resource utilization per test. 

MC.jl accomplishes the first task by choosing a starting point based on a markup rule guaranteed to produce a plausible equilibrium (one in which all products are individually profitable), updating potential equilibria action vectors according to best response functions, and changing the update formula according to the current Euclidean distance between the input action vector and the output action vector. Note that this procedure is not a contraction mapping; in practice convergence is obtained for all of the equilibria discussed in the paper.

MC.jl achieves some degree of resource efficiency by preallocating memory at the beginning of the equilibrium solver (see the ScratchPad struct on line 64 and the SolveMarketAndExportData function on line 452) and passing that memory throughout the stack of functions involved.

To produce the results in the paper, the code was run with Julia version 1.7.2 (commit bf53498635) and with the following packages loaded:
  [336ed68f] CSV v0.10.4
  [324d7699] CategoricalArrays v0.10.6
  [8f4d0f93] Conda v1.7.0
  [a93c6f00] DataFrames v1.3.6
  [163ba53b] DiffResults v1.0.3
  [31c24e10] Distributions v0.25.73
  [5789e2e9] FileIO v1.15.0
  [6a86dc24] FiniteDiff v2.15.0
  [26cc04aa] FiniteDifferences v0.12.24
  [9d5cd8c9] FixedEffectModels v1.7.0
  [f6369f11] ForwardDiff v0.10.32
  [28b8d3ca] GR v0.66.2
  [a98d9a8b] Interpolations v0.14.5
  [76087f3c] NLopt v0.6.5
  [2774e3e8] NLsolve v4.5.1
  [a03496cd] PlotlyBase v0.8.19
  [91a5bcdd] Plots v1.33.0
  [d330b81b] PyPlot v2.11.0
  [1463e38c] StatFiles v0.8.0
	
	